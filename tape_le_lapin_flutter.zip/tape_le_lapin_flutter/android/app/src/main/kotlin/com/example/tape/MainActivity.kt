package com.example.tape

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
